# -*- coding: utf-8 -*-
"""
Created on Mon Oct 30 19:44:02 2017
@author: user
"""
import time
import argparse
from flyai.dataset import Dataset
from keras.layers import Dense, Dropout, Conv2D, MaxPool2D, Flatten, BatchNormalization
from keras.models import Sequential
from model import Model
from path import MODEL_PATH
from keras.preprocessing.image import ImageDataGenerator
from flyai.utils.log_helper import train_log
from keras.callbacks import LearningRateScheduler
import numpy as np
from keras.optimizers import RMSprop
# from keras.utils import plot_model

parser = argparse.ArgumentParser()
parser.add_argument("-e", "--EPOCHS", default=10, type=int, help="train epochs")
parser.add_argument("-b", "--BATCH", default=16, type=int, help="batch size")
args = parser.parse_args()
'''
模型需要知道输入数据的shape，
因此，Sequential的第一层需要接受一个关于输入数据shape的参数，
后面的各个层则可以自动推导出中间数据的shape，
因此不需要为每个层都指定这个参数
'''
dataset = Dataset(epochs=args.EPOCHS, batch=args.BATCH)
model = Model(dataset)

# 构建网络
sqeue = Sequential()
sqeue.add(Conv2D(32, kernel_size = 3, activation='relu', input_shape = (28, 28, 1)))
sqeue.add(BatchNormalization())
sqeue.add(Conv2D(32, kernel_size = 3, activation='relu'))
sqeue.add(BatchNormalization())
sqeue.add(Conv2D(32, kernel_size = 5, strides=2, padding='same', activation='relu'))
sqeue.add(BatchNormalization())
sqeue.add(Dropout(0.4))

sqeue.add(Conv2D(64, kernel_size = 3, activation='relu'))
sqeue.add(BatchNormalization())
sqeue.add(Conv2D(64, kernel_size = 3, activation='relu'))
sqeue.add(BatchNormalization())
sqeue.add(Conv2D(64, kernel_size = 5, strides=2, padding='same', activation='relu'))
sqeue.add(BatchNormalization())
sqeue.add(Dropout(0.4))

sqeue.add(Conv2D(128, kernel_size = 4, activation='relu'))
sqeue.add(BatchNormalization())
sqeue.add(Flatten())
sqeue.add(Dropout(0.4))
sqeue.add(Dense(10, activation='softmax'))
sqeue.summary()
# plot_model(sqeue, show_shapes=True, to_file='model.png')
sqeue.compile(loss='categorical_crossentropy', optimizer="adam", metrics=['accuracy'])

#数据增强
data_augment = ImageDataGenerator(
        featurewise_center=False,  				# 在数据集上将输入平均值设置为0
        samplewise_center=False,  				# 将每个样本的平均值设置为0
        featurewise_std_normalization=False,    # 将输入除以数据集的std
        samplewise_std_normalization=False,  	# 将每个输入除以它的std
        zca_whitening=False,  					# 使用ZCA白化
        rotation_range=10,  					# 在范围内随机旋转图像（0到180度）
        zoom_range = 0.1, 						# 随机缩放图像
        width_shift_range=0.1,  				# 水平随机移动图像（总宽度的一部分）
        height_shift_range=0.1,  				# 垂直随机移动图像（总高度的一部分）
        horizontal_flip=False,  				# 随机翻转图像
        vertical_flip=False)  					# 随机翻转图像

# 设置一个学习率衰减
annealer = LearningRateScheduler(lambda x: 1e-3 * 0.95 ** x)

best_score = 0
val_acc_list = []
step = 0
for _ in range(dataset.get_step()):
    step += 1
    first_time = int(time.time())
    x_train, y_train = dataset.next_train_batch()
    x_val, y_val = dataset.next_validation_batch()
    # 数据增强
    batch_gen = data_augment.flow(x_train, y=y_train, batch_size=args.BATCH)
    x, y = next(batch_gen)

    history = sqeue.fit(x, y, batch_size=args.BATCH, verbose=0, 
						validation_data=(x_val, y_val),
						callbacks=[annealer])
    print(str(step) + "/" + str(dataset.get_step()))
    train_log(train_loss=history.history['loss'][0], train_acc=history.history['accuracy'][0],
              val_loss=history.history['val_loss'][0], val_acc=history.history['val_accuracy'][0])
    val_acc = history.history['val_accuracy'][0]
    # 用 val_acc_list 保存最新的 10 个 val_acc
    if len(val_acc_list) >= 10:
        val_acc_list.pop(0)
        val_acc_list.append(val_acc)
    else:
        val_acc_list.append(val_acc)
    # 每隔10步进行一次比较，用来保存最优结果
    if step % 10 == 0 and np.mean(val_acc_list) >= best_score:
        best_score = np.mean(val_acc_list)
        model.save_model(sqeue, MODEL_PATH, overwrite=True)
        print("********************  step %d, best accuracy %g" % (step, best_score))