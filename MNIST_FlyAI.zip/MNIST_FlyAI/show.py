from keras.preprocessing.image import ImageDataGenerator
from flyai.dataset import Dataset
import matplotlib.pyplot as plt
import numpy as np

#数据增强
data_augment = ImageDataGenerator(
        rotation_range=10,  # 在 [0, 指定角度] 范围内进行随机角度旋转
        zoom_range=0.1,  # 当制定一个数时，图片同时在长宽两个方向进行同等程度的放缩操作
        width_shift_range=0.1,  # 水平位置平移
        height_shift_range=0.1,  # 上下位置平移
     )

dataset = Dataset(epochs=1, batch=4)
for _ in range(dataset.get_step()):
    x_train, y_train = dataset.next_train_batch()
    # 展示原始图片
    fig = plt.figure()
    for i in range(4):
        img = np.concatenate([x_train[i, :], x_train[i, :], x_train[i, :]], axis=-1)
        sub_img = fig.add_subplot(241 + i)
        sub_img.imshow(img)
    # 对每批图像做数据增强
    batch_gen = data_augment.flow(x_train, y=y_train, batch_size=4)
    x, y = next(batch_gen)
    # 对增强之后的图片进行展示
    for i in range(4):
        img = np.concatenate([x[i,:], x[i,:], x[i,:]], axis=-1)
        sub_img = fig.add_subplot(241 + i + 4)
        sub_img.imshow(img)
    plt.show()